package WombatCRM;
/**
 * Possible actions within the CRM system
 *
 */
public enum Action {
	MAINMENU,
	EXIT,
	CUSTOMERSEARCH,
	CUSTOMERADD
}
