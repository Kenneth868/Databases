package WombatCRM;

/**
 * Application configuration for connection
 */
public class Configuration {
	public static final String Hostname = "klester03.sites.eeecs.qub.ac.uk"; // remote host or IP of MySQL server
	public static final boolean SSL = false; // Use SSL for host
	public static final String Username = "klester03"; // MySQL username for connection
	public static final String Password = "BkBPFmghz2x9XXKH"; // Connection password for MySQL
	public static final String Database = "klester03"; // Database name to connect to
}
